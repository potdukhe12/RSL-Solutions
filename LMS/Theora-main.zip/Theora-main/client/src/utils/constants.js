export const BASE_URL = import.meta.env.VITE_BASE_URL;
export const FIREBASE_CONFIG = import.meta.env.VITE_FIREBASE_CONFIG