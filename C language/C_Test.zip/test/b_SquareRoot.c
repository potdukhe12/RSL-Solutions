#include <math.h>
#include <stdio.h>
 
float sqRoot(float n) 
{
    return sqrt(n); 
}
 
int main()
{
    int n = 12;
 
    printf("%f ", sqRoot(n));
    return 0;
}