export const themeColors ={
    bg:'#EED6D3',
    at: '#67595E',
    bt: '#A49393',
    tx: '#E8B4B8',
}