import { View, Text } from 'react-native'
import React from 'react'

const GenderScreen = () => {
  return (
    <View>
      <Text>GenderScreen</Text>
    </View>
  )
}

export default GenderScreen